<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>FAQs Management</title>
  <link rel="stylesheet" href="./assets/tabler.min.css" />

  <style>
    @import url('https://rsms.me/inter/inter.css');

    :root {
      --tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto,
        Helvetica Neue, sans-serif;
    }

    body {
      font-feature-settings: 'cv03', 'cv04', 'cv11';
    }
  </style>
</head>

<body>
  <div class="container-fluid py-3">
    <h1 class="text-center">Edit FAQ</h1>
    <div class="row">
      <div class="col-lg-8 mx-auto">
        <div class="card mb-2">
          <div class="card-body">
            <div class="row">
              <div class="mb-3 col-md-6">
                <label for="category_id" class="form-label required">Category</label>

                <select
                  class="form-control form-select"
                  required="required"
                  id="category_id"
                  name="category_id"
                  aria-required="true">
                  <option value="1">SHIPPING</option>
                  <option value="2">PAYMENT</option>
                  <option value="3">ORDER & RETURNS</option>
                </select>
              </div>
              <div class="mb-3 col-md-6">
                <label for="status" class="form-label required">Status</label>

                <select
                  class="form-control form-select"
                  required="required"
                  id="status"
                  name="status"
                  aria-required="true">
                  <option value="published">Published</option>
                  <option value="draft">Draft</option>
                  <option value="pending">Pending</option>
                </select>
              </div>
              <div class="mb-3 col-12">
                <label for="question" class="form-label required">Question</label>
                <input type="text" class="form-control" name="question" id="question" />
              </div>
              <div class="mb-3 col-12">
                <label for="answer" class="form-label required">Answer</label>
                <textarea
                  class="form-control"
                  rows="4"
                  required="required"
                  name="answer"
                  cols="50"
                  id="answer"></textarea>
              </div>
            </div>
            <button type="button" class="btn btn-primary">Save</button>
            <button type="button" class="btn">Cancel</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="./assets/tabler.min.js"></script>
</body>

</html>